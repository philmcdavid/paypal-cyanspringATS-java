package com.cyanspring.common;

import java.util.Date;

public interface IClockListener {
	void onTime(Date time);
}
