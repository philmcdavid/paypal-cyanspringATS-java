package com.cyanspring.common;

public interface IPlugin {
	void init() throws Exception;
	void uninit();
}
