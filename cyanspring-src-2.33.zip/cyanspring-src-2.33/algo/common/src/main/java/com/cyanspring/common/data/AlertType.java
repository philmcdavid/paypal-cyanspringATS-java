package com.cyanspring.common.data;

public enum AlertType {
	ALERT0, 
	ALERT1, 
	ALERT2, 
	ALERT3, 
	ALERT4, 
	ALERT5, 
	ALERT6, 
	ALERT7, 
	ALERT8, 
	ALERT9, 
	WARNING, 
	ERROR
}
