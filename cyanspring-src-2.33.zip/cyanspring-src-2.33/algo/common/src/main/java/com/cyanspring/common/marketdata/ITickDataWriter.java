package com.cyanspring.common.marketdata;

public interface ITickDataWriter {
	String quoteToString(Quote quote);
}
