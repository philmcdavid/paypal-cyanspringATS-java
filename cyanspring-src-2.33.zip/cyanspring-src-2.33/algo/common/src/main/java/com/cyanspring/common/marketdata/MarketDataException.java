package com.cyanspring.common.marketdata;

public class MarketDataException extends Exception {
	private static final long serialVersionUID = 7383158339098601099L;

	public MarketDataException(String message) {
		super(message);
	}
}
