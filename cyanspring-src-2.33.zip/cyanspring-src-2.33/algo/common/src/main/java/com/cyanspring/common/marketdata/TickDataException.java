package com.cyanspring.common.marketdata;

public class TickDataException extends Exception {
	private static final long serialVersionUID = -139248299932144021L;

	public TickDataException(String message) {
		super(message);
	}

}
