package com.cyanspring.common.timeseries;

public enum TrendEnum {
	UP, FLAT, DOWN, NA
}
