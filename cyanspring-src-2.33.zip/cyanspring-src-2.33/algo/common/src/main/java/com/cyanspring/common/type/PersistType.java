package com.cyanspring.common.type;

public enum PersistType {
	SINGLE_ORDER_STRATEGY,
	SINGLE_INSTRUMENT_STRATEGY,
	MULTI_INSTRUMENT_STRATEGY,
	SIGNAL,
}
