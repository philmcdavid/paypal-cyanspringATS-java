package com.cyanspring.event;

public class AsyncThreadStat {
	public static boolean showStat;

	public static boolean isShowStat() {
		return showStat;
	}

	public static void setShowStat(boolean showStat) {
		AsyncThreadStat.showStat = showStat;
	}
	
}
