package com.cyanspring.sample.singleorder.stop;

import com.cyanspring.common.business.ParentOrder;
import com.cyanspring.common.marketdata.Quote;
import com.cyanspring.common.strategy.PriceAllocation;
import com.cyanspring.common.strategy.PriceInstruction;
import com.cyanspring.common.type.ExchangeOrderType;
import com.cyanspring.common.util.PriceUtils;
import com.cyanspring.strategy.singleorder.AbstractPriceAnalyzer;
import com.cyanspring.strategy.singleorder.QuantityInstruction;
import com.cyanspring.strategy.singleorder.SingleOrderStrategy;

public class StopPriceAnalyzer extends AbstractPriceAnalyzer {

	@Override
	protected PriceInstruction calculate(QuantityInstruction qtyInstruction,
			SingleOrderStrategy strategy) {
		ParentOrder order = strategy.getParentOrder();
		Quote quote = strategy.getQuote();
		PriceInstruction pi = new PriceInstruction();
		if(PriceUtils.Equal(qtyInstruction.getAggresiveQty(), 0))
			return pi;
		
		if(order.getSide().isBuy() && 
		   PriceUtils.validPrice(quote.getAsk()) && 
		   PriceUtils.EqualLessThan(order.getPrice(), quote.getAsk()) || 
		   !order.getSide().isBuy() && 
		   PriceUtils.validPrice(quote.getBid()) && 
		   PriceUtils.EqualGreaterThan(order.getPrice(), quote.getBid()) ) {
			pi.add(new PriceAllocation(order.getSymbol(), order.getSide(), order.getPrice(), 
					qtyInstruction.getAggresiveQty(), 
					ExchangeOrderType.LIMIT, strategy.getId()));
		}
		
		return pi;
	}

}
